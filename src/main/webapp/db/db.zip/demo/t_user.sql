CREATE TABLE `t_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lname` varchar(20) DEFAULT NULL COMMENT '用户名称',
  `lpswd` varchar(32) DEFAULT NULL COMMENT '密码',
  `email` varchar(128) DEFAULT NULL COMMENT '邮箱',
  `ctime` datetime DEFAULT NULL COMMENT '创建时间',
  `last_login_time` datetime DEFAULT NULL COMMENT '最后登录时间',
  `status` int(11) DEFAULT '1' COMMENT '1:有效，0:失效',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

INSERT INTO `t_user` VALUES (1, 'admin', 'e10adc3949ba59abbe56e057f20f883e', 'admin', '2016-6-16 11:15:33', '2016-6-16 11:24:10', 1);
INSERT INTO `t_user` VALUES (11, 'manager', 'e10adc3949ba59abbe56e057f20f883e', '8446666@qq.com', '2016-5-26 20:50:54', '2016-6-16 11:24:35', 1);
INSERT INTO `t_user` VALUES (12, 'user01', 'e10adc3949ba59abbe56e057f20f883e', '8446666', '2016-5-27 22:34:19', '2016-6-15 17:03:16', 1);
