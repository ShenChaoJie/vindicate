CREATE TABLE `t_dict` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dict_type_code` varchar(36) NOT NULL COMMENT '字典类型',
  `dict_code` varchar(50) NOT NULL COMMENT '字典key',
  `dict_name` varchar(200) NOT NULL COMMENT '字典value',
  `project_name` varchar(50) DEFAULT NULL COMMENT '所属项目名称',
  `ctime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=831 DEFAULT CHARSET=utf8 COMMENT='字典表';
