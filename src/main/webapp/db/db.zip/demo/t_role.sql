CREATE TABLE `t_role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_name` varchar(32) DEFAULT NULL COMMENT '角色名称',
  `role_type` varchar(10) DEFAULT NULL COMMENT '角色类型',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='角色表';

INSERT INTO `t_role` VALUES (1, 'admin', '888888');
INSERT INTO `t_role` VALUES (3, 'manager', '100003');
INSERT INTO `t_role` VALUES (4, 'user', '100002');
