CREATE TABLE `t_user_role` (
  `user_id` int(11) DEFAULT NULL COMMENT '用户ID',
  `role_id` int(11) DEFAULT NULL COMMENT '角色ID'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='用户角色关系表';


INSERT INTO `t_user_role` VALUES (12, 4);
INSERT INTO `t_user_role` VALUES (11, 3);
INSERT INTO `t_user_role` VALUES (11, 4);
INSERT INTO `t_user_role` VALUES (1, 1);
