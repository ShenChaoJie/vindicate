CREATE TABLE `t_role_permission` (
  `role_id` int(20) DEFAULT NULL COMMENT '角色ID',
  `permission_id` int(20) DEFAULT NULL COMMENT '权限ID'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='角色权限关系表';


INSERT INTO `t_role_permission` VALUES (4, 8);
INSERT INTO `t_role_permission` VALUES (4, 9);
INSERT INTO `t_role_permission` VALUES (4, 10);
INSERT INTO `t_role_permission` VALUES (4, 11);
INSERT INTO `t_role_permission` VALUES (4, 12);
INSERT INTO `t_role_permission` VALUES (3, 4);
INSERT INTO `t_role_permission` VALUES (3, 6);
INSERT INTO `t_role_permission` VALUES (3, 7);
INSERT INTO `t_role_permission` VALUES (3, 13);
INSERT INTO `t_role_permission` VALUES (3, 14);
INSERT INTO `t_role_permission` VALUES (3, 15);
INSERT INTO `t_role_permission` VALUES (3, 16);
INSERT INTO `t_role_permission` VALUES (3, 17);
INSERT INTO `t_role_permission` VALUES (3, 18);
INSERT INTO `t_role_permission` VALUES (3, 19);
INSERT INTO `t_role_permission` VALUES (3, 20);
INSERT INTO `t_role_permission` VALUES (1, 4);
INSERT INTO `t_role_permission` VALUES (1, 6);
INSERT INTO `t_role_permission` VALUES (1, 7);
INSERT INTO `t_role_permission` VALUES (1, 8);
INSERT INTO `t_role_permission` VALUES (1, 9);
INSERT INTO `t_role_permission` VALUES (1, 10);
INSERT INTO `t_role_permission` VALUES (1, 11);
INSERT INTO `t_role_permission` VALUES (1, 12);
INSERT INTO `t_role_permission` VALUES (1, 13);
INSERT INTO `t_role_permission` VALUES (1, 14);
INSERT INTO `t_role_permission` VALUES (1, 15);
INSERT INTO `t_role_permission` VALUES (1, 16);
INSERT INTO `t_role_permission` VALUES (1, 17);
INSERT INTO `t_role_permission` VALUES (1, 18);
INSERT INTO `t_role_permission` VALUES (1, 19);
INSERT INTO `t_role_permission` VALUES (1, 20);
